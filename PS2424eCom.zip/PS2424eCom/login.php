<?php
$host="localhost";
$user="root";
$password="";
$db="myshop";

$con=mysqli_connect($host,$user,$password,$db);

if(isset($_POST['Username'])){
	$Username=$_POST['Username'];
	$Password=$_POST['Password'];
	$sql="select * from register where Username='".$Username."' AND Password='".$Password."' limit 1";
	$result=mysqli_query($con,$sql);
	if(mysqli_num_rows($result)==1){
		echo("<script> alert('Logged Successfully..')</script>");
		echo("<script>window.location = 'home.html';</script>");
		//header("Location:home.html");
		exit();
	}
	else{
		echo("<script> alert('Incorrect Password..')</script>");
		echo("<script>window.location = 'login.html';</script>");
		exit();
}}
?>