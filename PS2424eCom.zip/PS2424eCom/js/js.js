function fun(){
            var Username=document.forms["myform"]["Username"].value;
            var Email=document.forms["myform"]["Email"].value;
            var Password=document.forms["myform"]["Password"].value;
            var Repassword=document.forms["myform"]["Repassword"].value;


        if(Username==null || Username=="" ){
                  document.getElementById("errorBox").innerHTML =
                   "USERNAME ???";
                 return false;
        }

        if(Email==null || Email==""){
                  document.getElementById("errorBox").innerHTML =
                   "EMAIL ???";
                 return false;
        }

        if(Password==null || Password=="" ){
                  document.getElementById("errorBox").innerHTML =
                   "PASSWORD ???";
                 return false;
        }

        if(Repassword==null || Repassword==""){
                  document.getElementById("errorBox").innerHTML =
                   "CONFIRM PASSWORD ???";
                 return false;}

 		if(Password != Repassword){
                  document.getElementById("errorBox").innerHTML =
                   "PASSWORD NOT MATCH...";
                 return false;}

        

        if (Username != '' && Password != '' && Repassword != '' && Email != '' && Password == Repassword)

          alert("Register Successfully..");

}
