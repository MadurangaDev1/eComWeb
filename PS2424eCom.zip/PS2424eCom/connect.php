<?php
$Username=$_POST['Username'];
$Email=$_POST['Email'];
$Password=$_POST['Password'];
$Repassword=$_POST['Repassword'];

$conn = new mysqli('localhost','root','','myshop');
if($conn->connect_error){
	die('Connection Failed : '.$conn->connect_error);
}else if ($Username==''){
	echo"js/js.js";

}else{
	$stmt = $conn->prepare("insert into register(Username,Email,Password,Repassword)
	values(?, ?, ?, ?)");
	$stmt->bind_param("ssss",$Username,$Email,$Password,$Repassword);
	$stmt->execute();
	header("Location:home.html");
	$stmt->close();
	$conn->close();
}
?>