const plants = [
  {
    id: 1,
    name: 'iPhone 14 Pro',
    price: '999',
    like: true,
    img: require('../assets/ip1.jpg'),
    about:
      'From $999or $41.62/mo.per month for 24 mo.months before trade‑inFootnote*',
  },

  {
    id: 2,
    name: 'iPhone 14',
    price: '799',
    like: false,
    img: require('../assets/ip2.jpg'),
    about:
      'From $799or $33.29/mo.per month for 24 mo.months before trade‑in',
  },
  {
    id: 3,
    name: 'iPhone 13 mini',
    price: '699',
    like: false,
    img: require('../assets/ip3.jpg'),
    about:
      'From $699or $29.12/mo.per month for 24 mo.months before trade‑in',
  },

 
  
];

export default plants;