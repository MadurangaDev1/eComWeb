
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  Alert,
  TouchableOpacity
} from "react-native";

const LogScreen = ({navigation}) => {
  const [username, setUname] = useState("");
  const [password, setPword] = useState("");
  return (
    <View style={styles.container}>
      <Image style={styles.image} source={require("../assets/logo.png")} /> 
     
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          placeholder="Username"
          placeholderTextColor="#154377ff"
          onChangeText={(username) => setUname(username)}
        /> 
      </View> 
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          placeholder="Password"
          placeholderTextColor="#154377ff"
          secureTextEntry={true}
          onChangeText={(password) => setPword(password)}
        /> 
      </View> 
      <TouchableOpacity>
        <Text style={styles.forgot_button}>Forgot Password?</Text> 
      </TouchableOpacity> 
      <TouchableOpacity
        style={styles.loginBtn}
        onPress={() => {
          var uname = username;
          var pword = password;
          if (uname == '1' && pword == '1') {
            Alert.alert('Login');
            navigation.navigate('Home');
          } else {
            Alert.alert('Error');
          }
        }}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View> 
  );
};

export default LogScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  image: {
    marginBottom: 40,
  },
  inputView: {
    
    borderRadius: 3,
    borderColor:"#154377ff",
    borderWidth:1,
    width: "70%",
    height: 45,
    marginBottom: 20,
    alignItems: "center",
  },
  inputText: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 20,
  },
  forgot_button: {
    height: 30,
    marginBottom: 30,
  },
  loginBtn: {
    width: "80%",
    borderRadius: 3,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    backgroundColor: "#154377ff",
  },
  buttonText:{
    color:"#ffffff",
  },
});